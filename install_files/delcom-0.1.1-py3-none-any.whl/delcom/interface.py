import time
import math
import copy
import struct
import serial
import serial.tools.list_ports
import logging
import threading
from typing import List
from collections import namedtuple
from dataclasses import dataclass
from delcom.calc import Units, SCALE_MULTIPLIERS
from delcom.calc import calc_mhos, determine_range

log = logging.getLogger('delcom.interface')

MARK_START = b'S'
MARK_RESP = b'Ss'
CMD_GET_STATUS = b'q'
CMD_GET_SENSOR_INFO = b'S'
CMD_GET_SENSOR_MEAS = b'd'
CMD_GET_SENSOR_STATUS = b'Q'
CMD_GET_RAW_VOLTAGES = b'G'
CMD_GET_RAW_TEMPS = b'T'
CMD_GET_IP_INFO = b'P'
CMD_GET_EE = b'E'
CMD_SET_ALL_RANGE_HI = b'H'
CMD_SET_ALL_RANGE_LO = b'L'
CMD_SET_ONE_RANGE_HI = b'h'
CMD_SET_ONE_RANGE_LO = b'l'
CMD_ZERO_SENSORS = b'Z'
CMD_REBOOT = b'B'
CMD_PUT_EE = b'D'
CMD_SET_UNITS = b'U'
CMD_SET_IP_MODE = b'M'
CMD_SET_IP_ADDRESSES = b'i'

RSP_ACK = b'A'

# CMD_PC_CALIBRATE = b'C' is is calibrate or clear?
# CMD_AUTOZERO = b'A'   # does not exist?


ModuleInfo = namedtuple('ModuleInfo', ('device', 'usb_serial_num'))
InterfaceStatus = namedtuple('InterfaceStatus', ('revision', 'sensor_in_error', 'status'))
SensorInfo = namedtuple('SensorInfo', ('serial_num', 'firmware_rev'))
SensorTemperatures = namedtuple('SensorTemperatures', ('top', 'bot', 'board'))


@dataclass
class IpConfig:
    use_dhcp: bool
    ip_addr: str
    subnet: str
    gateway: str
    dns: str


@dataclass
class IpInfo:
    ip_addr: str
    ip_config: IpConfig


@dataclass
class SensorConfig:
    calibration_mult_lo: float
    calibration_mult_hi: float
    offset: float               # in mhos
    serial_num: str
    tempco_top_lo: int
    tempco_top_hi: int
    tempco_bot_lo: int
    tempco_bot_hi: int
    tempco_board_lo: int
    tempco_board_hi: int
    auto_zero_threshold: int    # A/D counts
    scale_idx_lo: int
    scale_idx_hi: int
    range_to_use: int           # 0: low, 1: high
    use_calibration: bool
    use_offset: bool
    use_auto_zero: bool


def unpack_ipv4(buf: bytes, offset: int = 0) -> str:
    return '.'.join(['%i' % buf[offset + i] for i in range(4)])


# NOTE the byte order is reversed between reading and writing
def pack_ipv4(ip: str) -> bytes:
    return bytes([int(x) for x in ip.split('.')[::-1]])


def bin2asc(b):
    return ' '.join([f'{v:02X}' for v in b])


def _send_command(ser: serial.Serial, cmd: bytes):
    pkt = bytearray(MARK_START)
    pkt.append(len(cmd) + 3)
    pkt.extend(cmd)
    pkt.append(((sum(pkt) & 0xFF) ^ 0xFF) + 1)
    ser.write(pkt)
    ser.flushInput()


def _recv_response(ser: serial.Serial, timeout: float = 0.1):
    pkt = bytearray()
    mark = time.time()
    while True:
        # did this hit the timeout mark
        if time.time() - mark > timeout:
            log.debug('recv_response timeout')
            return bytearray()
        pkt.extend(ser.read(255))
        # look for start byte, removing any leading junk
        while len(pkt) > 0 and pkt[0] not in MARK_RESP:
            log.debug(f'recv_response extraneous byte 0x{pkt[0]:02X}')
            pkt.pop(0)
        # check if packet is complete
        if len(pkt) < 3:
            continue
        exp_len = pkt[1]
        if len(pkt) < exp_len:
            continue
        # check the checksum (sum of bytes should be 0)
        # ignore anything after specified length
        if sum(pkt[:exp_len]) & 0xFF != 0:
            log.debug(f'recv_response bad checksum 0x{pkt[exp_len - 1]:02X}')
            # print(' '.join(['%02X' % b for b in pkt]))
            pkt = pkt[exp_len:]
            continue
        return pkt[2:-1]


def _query_module(ser: serial.Serial, cmd: bytes, timeout: float = 0.2, blk_sz: int = 0, exp_len: int = 0):
    _send_command(ser, cmd)
    raw = _recv_response(ser, timeout)
    if exp_len:
        if len(raw) != exp_len:
            raise RuntimeError(f'received invalid length {len(raw)}, expected {exp_len}')
    if blk_sz:
        _, extra = divmod(len(raw), blk_sz)
        if extra != 0:
            raise RuntimeError(f'received invalid length {len(raw)}, expected div {blk_sz}')
    return raw


def _check_ack(resp):
    if not resp:
        raise RuntimeError('no response')
    if resp != RSP_ACK:
        raise RuntimeError(f'no ACK, received 0x{resp[0]:02X}')


def enumerate_modules() -> List[ModuleInfo]:
    """
    Returns a list of attached Delcom Interface modules
    """
    ser = None
    mods = []
    for p in serial.tools.list_ports.comports():
        vid = f'0x{p.vid:04X}' if isinstance(p.vid, int) else 'unknown'
        pid = f'0x{p.pid:04X}' if isinstance(p.pid, int) else 'unknown'
        log.debug(f'enumerate, {p.device} {p.description} vid: 0x{vid} pid: 0x{pid}')
        if p.vid != 0x0403:
            continue
        try:
            ser = serial.Serial(
                port=p.device,
                baudrate=115200,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=0.01
            )
        except (PermissionError, serial.serialutil.SerialException):
            log.debug(f'enumerate, unable to open port {p.device}')
            continue
        resp = _query_module(ser, CMD_GET_SENSOR_INFO, 0.1)
        ser.close()
        if not resp:
            continue

        mods.append(ModuleInfo(p.device, p.serial_number))
    return mods


class Interface():
    def __init__(self, dev: str = None):
        self.fw_rev = None

        self._dev = None
        self._ser = None
        self._sensor_configs = []
        self._units = None
        self._thickness_um = None
        self._resistivity_ohm_um = None
        self._lock = threading.Lock()

        if dev:
            self.connect(dev)

    def __enter__(self):
        self._lock.acquire()
        return self

    def __exit__(self, exc_type, exc_value, exc_tb):
        self._lock.release()

    def connect(self, dev: str = 'auto'):
        self.disconnect()
        if dev == 'auto':
            mods = enumerate_modules()
            if len(mods) == 0:
                raise RuntimeError('interface module not found')
            dev = mods[0].device

        self._ser = serial.Serial(
            port=dev,
            baudrate=115200,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            bytesize=serial.EIGHTBITS,
            timeout=0.1
        )

        try:
            status = self.read_status()
            sensors = self.read_sensor_list()
        except Exception:
            raise
            raise RuntimeError('unable to communicate with Interface Module')

        self.fw_rev = status.revision
        self._sensor_configs = [None] * len(sensors)
        self._dev = dev
        return dev

    def disconnect(self):
        if self._ser:
            self._ser.close()
            self._ser = None
            self._dev = None
            self._units = None
            self._thickness_um = None
            self._resistivity_ohm_um = None
            self.fw_rev = None

    def sensor_count(self):
        return len(self._sensor_configs)

    def is_connected(self) -> bool:
        return self._ser and self._ser.is_open

    def _require_connected(self):
        if not self.is_connected():
            raise RuntimeError('interface module not connected')

    def _get_config(self, idx: int) -> SensorConfig:
        if self._sensor_configs[idx] is None:
            self._sensor_configs[idx] = self._read_sensor_config(idx)
        return copy.copy(self._sensor_configs[idx])

    def _read_sensor_config(self, idx: int) -> SensorConfig:
        self._require_connected()
        raw = _query_module(self._ser, CMD_GET_EE + bytes([idx]), exp_len=34, timeout=0.2)
        # print('READ RAW', bin2asc(raw))
        vals = struct.unpack_from('<fffHhhhhhhHBBBBBB', raw, 0)
        sensor_config = SensorConfig(
            calibration_mult_lo=vals[0],
            calibration_mult_hi=vals[1],
            offset=vals[2],
            serial_num=str(vals[3]),   # represent serial number as string
            tempco_top_lo=vals[4],
            tempco_top_hi=vals[5],
            tempco_bot_lo=vals[6],
            tempco_bot_hi=vals[7],
            tempco_board_lo=vals[8],
            tempco_board_hi=vals[9],
            auto_zero_threshold=vals[10],
            scale_idx_lo=vals[11],
            scale_idx_hi=vals[12],
            range_to_use=vals[13],
            use_calibration=bool(vals[14]),
            use_offset=bool(vals[15]),
            use_auto_zero=bool(vals[16])
        )
        while idx >= len(self._sensor_configs):
            self._sensor_configs.append(None)
        self._sensor_configs[idx] = sensor_config
        return copy.copy(sensor_config)

    def _write_sensor_config(self, idx: int, cfg: SensorConfig):
        self._require_connected()
        if idx >= len(self._sensor_configs) or idx < 0:
            raise IndexError('index is out of bounds for connected sensors')
        if self._sensor_configs[idx] is None:
            self._sensor_configs[idx] = self._read_sensor_config(self, idx)
        cur_cfg = self._sensor_configs[idx]
        if cur_cfg.serial_num != cfg.serial_num:
            raise ValueError('changing serial number is not allowed')

        data = struct.pack('<fffHhhhhhhHBBBBBB',
                           cfg.calibration_mult_lo,
                           cfg.calibration_mult_hi,
                           cfg.offset,
                           int(cfg.serial_num),
                           cfg.tempco_top_lo,
                           cfg.tempco_top_hi,
                           cfg.tempco_bot_lo,
                           cfg.tempco_bot_hi,
                           cfg.tempco_board_lo,
                           cfg.tempco_board_hi,
                           cfg.auto_zero_threshold,
                           cfg.scale_idx_lo,
                           cfg.scale_idx_hi,
                           cfg.range_to_use,
                           int(cfg.use_calibration),
                           int(cfg.use_offset),
                           int(cfg.use_auto_zero))
        # print('WRIT RAW', bin2asc(data))
        cmd = CMD_PUT_EE + bytes([idx]) + data
        raw = _query_module(self._ser, cmd, timeout=5)
        _check_ack(raw)
        self._sensor_configs[idx] = copy.copy(cfg)

    def get_sensor_range_values(self, idx: int):
        if self._sensor_configs[idx] is None:
            self._sensor_configs[idx] = self._read_sensor_config(idx)
        cfg = self._sensor_configs[idx]
        scale_idx = cfg.scale_idx_lo + cfg.range_to_use
        lo, hi = determine_range(scale_idx, self._units, self._thickness_um, self._resistivity_ohm_um)
        return lo, hi

    def read_status(self) -> InterfaceStatus:
        self._require_connected()
        raw = _query_module(self._ser, CMD_GET_STATUS, exp_len=4)
        status = struct.unpack_from('>H', raw, 0)[0]
        bad_idx = None if raw[2] == 0xFF else raw[2]
        rev = raw[3]
        return InterfaceStatus(rev, bad_idx, status)

    def read_sensor_list(self) -> List[SensorInfo]:
        self._require_connected()
        raw = _query_module(self._ser, CMD_GET_SENSOR_INFO, blk_sz=3)
        sensors = []
        for o in range(0, len(raw), 3):
            vals = struct.unpack_from('<HB', raw, o)
            sensors.append(SensorInfo(str(vals[0]), vals[1]))
        return sensors

    def read_sensor_status(self) -> List[int]:
        self._require_connected()
        raw = _query_module(self._ser, CMD_GET_SENSOR_STATUS, blk_sz=2)
        values = []
        for o in range(0, len(raw), 2):
            values.append(struct.unpack_from('>H', raw, o)[0])
        return values

    def read_sensors(self, format_str: bool = False) -> List[float]:
        """
        Read and return all sensors values from the interface module.
        If format_str is True, the values will be string representations of the values.
        Also, the string values may hold special values
            string      conversion
            --------    ----------
            INFINITE    math.inf
            *FAULT**    math.nan
            OVR RANG    math.nan
        """
        self._require_connected()
        raw = _query_module(self._ser, CMD_GET_SENSOR_MEAS, blk_sz=8)
        values = []
        for o in range(0, len(raw), 8):
            if format_str:
                values.append(raw[o:o + 8].decode('utf8'))
            else:
                if raw[o:o + 8] == b'INFINITE':
                    values.append(math.inf)
                elif raw[o] in b'*FO':
                    values.append(math.nan)
                else:
                    values.append(float(raw[o:o + 8]))
        return values

    def read_sensor_voltages(self, format_str: bool = False) -> List[float]:
        """
        Read and return the raw voltages from the sensors.
        If format_str is True, the values will be string representations of the values.
        """
        self._require_connected()
        raw = _query_module(self._ser, CMD_GET_RAW_VOLTAGES, blk_sz=2)
        values = []
        for o in range(0, len(raw), 2):
            v = struct.unpack_from('>H', raw, o)[0] * 2.5 / 65535
            if format_str:
                values.append(f'{v:.4f}')
            else:
                values.append(v)
        return values

    def read_sensor_temperatures(self) -> List[SensorTemperatures]:
        self._require_connected()
        raw = _query_module(self._ser, CMD_GET_RAW_TEMPS, blk_sz=6)
        values = []
        for o in range(0, len(raw), 6):
            t = struct.unpack_from('>HHH', raw, o)
            values.append(SensorTemperatures(t[0] / 128.0, t[1] / 128.0, t[2] / 128.0))
        return values

    def read_ip_info(self) -> IpInfo:
        self._require_connected()
        raw = _query_module(self._ser, CMD_GET_IP_INFO, exp_len=21)
        static_ip = unpack_ipv4(raw, 0)
        subnet = unpack_ipv4(raw, 4)
        gateway = unpack_ipv4(raw, 8)
        dns = unpack_ipv4(raw, 12)
        ip = unpack_ipv4(raw, 16)
        use_dhcp = raw[20] != 0
        return IpInfo(ip, IpConfig(use_dhcp, static_ip, subnet, gateway, dns))

    def set_all_sensors_range(self, hi: int):
        """
        Sets the measurement range (0 is low, 1 is high) of all sensors.
        """
        self._require_connected()
        cmd = CMD_SET_ALL_RANGE_HI if hi else CMD_SET_ALL_RANGE_LO
        raw = _query_module(self._ser, cmd, timeout=0.2)
        _check_ack(raw)
        for idx in range(len(self._sensor_configs)):
            self._read_sensor_config(idx)

    def set_sensor_range(self, idx: int, hi: int):
        """
        Sets the measurement range (0 is low, 1 is high) of the sensor.
        """
        self._require_connected()
        cmd = CMD_SET_ONE_RANGE_HI if hi else CMD_SET_ONE_RANGE_LO
        cmd += bytes([idx])
        raw = _query_module(self._ser, cmd, timeout=0.2)
        _check_ack(raw)
        self._read_sensor_config(idx)

    def set_units(self, units: Units, /, thickness_um: float = None, resistivity_ohm_um: float = None):
        """
        Selects which parameter and units to display and returned via read_sensors()
        units:
          Units.OHMS_PER_SQ: sheet resistance in ohms/sq
          Units.MHOS_PER_SQ: sheet conductance in mhos/sq
          Units.MICRONS: thickness in microns, resistivity_ohms must be set
          Units.OHMS_CM: volume resistivity in ohms-cm, thickness_um must be set
          Units.U_OHMS_CM: volume resistivity in u-ohms-cm, thickness_um must be set
          Units.VOLTS: not supported
        thickness_um: thickness of material in microns
        resistivity_ohm_um: resistivity of material in ohms-um
        """
        cmd = CMD_SET_UNITS + bytes([units])
        if units == Units.OHMS_PER_SQ or units == Units.MHOS_PER_SQ:
            pass
        elif units == Units.MICRONS:
            if resistivity_ohm_um is None:
                raise ValueError('resistivity must be set for MICRONS')
            cmd += struct.pack('<f', resistivity_ohm_um)
        elif units == Units.OHMS_CM:
            if thickness_um is None:
                raise ValueError('thickness must be set for OHMS_CM')
            # interface module uses thickness in cm
            cmd += struct.pack('<f', thickness_um / 10000)
        elif units == Units.U_OHMS_CM:
            if thickness_um is None:
                raise ValueError('thickness must be set for U_OHMS_CM')
            # interface module uses thickness in cm
            cmd += struct.pack('<f', thickness_um * 100)
        else:
            raise ValueError('unknown units value')
        raw = _query_module(self._ser, cmd, timeout=0.2)
        _check_ack(raw)
        self._units = units
        self._thickness_um = thickness_um
        self._resistivity_ohm_um = resistivity_ohm_um

    def set_auto_zero(self, idx: int, enable: bool, /, threshold: float = None, units: Units = None, thickness_um: float = None, resistivity_ohm_um: float = None):
        """
        Enable/disable use of auto zero function and optionally set the threshold.
        Threshold is point where the conductance will report 0.0 if value is below that value.
        """
        self._require_connected()
        cfg = self._get_config(idx)
        cfg.use_auto_zero = bool(enable)
        if threshold is not None:
            mhos = calc_mhos(threshold, units, thickness_um, resistivity_ohm_um)
            if cfg.range_to_use:
                mult = SCALE_MULTIPLIERS.get(cfg.scale_idx_hi, 1)
                cal = cfg.calibration_mult_hi if cfg.use_calibration else 1
            else:
                mult = SCALE_MULTIPLIERS.get(cfg.scale_idx_lo, 1)
                cal = cfg.calibration_mult_lo if cfg.use_calibration else 1
            if cal < 0:
                cal = -cal
            counts = int(mhos * 65535 / (2.5 * mult * cal))
            cfg.auto_zero_threshold = counts
            # print(f'{counts=}')
        self._write_sensor_config(idx, cfg)

    def set_offset(self, idx: int, enable: bool, /, offset: float = None, units: Units = None, thickness_um: float = None, resistivity_ohm_um: float = None):
        """
        Enable/disable use of conductance offset and optionally set the offset.
        Offset is the value of conductance to subtract from measurement.
        Note, this offset works on conductance, if a resistance is provided
        the offset will be 1/resistance.
        """
        self._require_connected()
        cfg = self._get_config(idx)
        cfg.use_offset = bool(enable)
        if offset is not None:
            mhos = calc_mhos(offset, units, thickness_um, resistivity_ohm_um)
            cfg.offset = mhos
        self._write_sensor_config(idx, cfg)

    def set_temperature_coeffs(self, idx: int, tempco_top: int, tempco_bot: int, tempco_board: int):
        """
        Set the temperature coefficients for the coils within a sensor.
        The units of coefficients are in counts / deg C
        """
        self._require_connected()
        cfg = self._get_config(idx)
        if cfg.range_to_use:
            cfg.tempco_top_hi = tempco_top
            cfg.tempco_bot_hi = tempco_bot
            cfg.tempco_board_hi = tempco_board
        else:
            cfg.tempco_top_lo = tempco_top
            cfg.tempco_bot_lo = tempco_bot
            cfg.tempco_board_lo = tempco_board
        self._write_sensor_config(idx, cfg)

    def set_slope_calibration(self, idx: int, enable, /, cal: float = None):
        """
        Enable/disable use of slope calibration and optionally set the calibration value.
        The calibration should be set using calibrate_slope_prep()/calibrate_slope()
        """
        self._require_connected()
        cfg = self._get_config(idx)
        cfg.use_calibration = bool(enable)
        if cal is not None:
            if cfg.range_to_use:
                cfg.calibration_mult_hi = cal
            else:
                cfg.calibration_mult_lo = cal
        self._write_sensor_config(idx, cfg)

    def calibrate_slope_prep(self, idx: int, /, rezero: bool = False, range_to_cal: int = None):
        """
        Prepare the interface module and sensor for sensor slope calibration.
        Auto_zero, calibration, and offset are disabled and are not automatically
        enabled after calibration.
        Optionally a zero of module is performed, but sensors need to be empty.
        Optionally the range is selected, however range should normally
        be left unchanged from the factory setting.
        """
        self._require_connected()
        self.set_units(Units.MHOS_PER_SQ)

        if range_to_cal is not None:
            # setting the range in the cfg object and writing cfg
            # does not make range change take effect immediately
            # need to use specific function to set the range
            # this also needs time to settle
            self.set_sensor_range(idx, range_to_cal)
            time.sleep(2)

        if rezero:
            # if a zero is run, the config must be written after
            # but zero needs time to run
            self.zero_all_sensors()
            time.sleep(2)

        cfg = self._get_config(idx)
        cfg.use_auto_zero = 0
        cfg.use_calibration = 0
        cfg.use_offset = 0
        self._write_sensor_config(idx, cfg)

    def calibrate_slope(self, idx: int, ref_value: float, units: Units, thickness_um: float = None, resistivity_ohm_um: float = None) -> float:
        """
        The sensor must have a known sample, that value will be measured
        and the correction factor will be calculated based on the specific ref_value.
        The correction factor is stored in sensor and is also returned
        """
        self._require_connected()

        SAMPLE_COUNT = 4
        cfg = self._get_config(idx)
        ref_mhos = calc_mhos(ref_value, units, thickness_um, resistivity_ohm_um)

        meas_mhos = 0
        meas_volts = 0
        for _ in range(SAMPLE_COUNT):
            values = self.read_sensors()
            meas_mhos += values[idx]
            volts = self.read_sensor_voltages()
            meas_volts += volts[idx]
            # print(volts, values)
        meas_mhos /= SAMPLE_COUNT
        meas_volts /= SAMPLE_COUNT
        cal = ref_mhos / meas_mhos
        if cfg.range_to_use:
            cfg.calibration_mult_hi = cal
        else:
            cfg.calibration_mult_lo = cal

        self._write_sensor_config(idx, cfg)
        return cal

    def write_ip_config(self, cfg: IpConfig):
        self._require_connected()
        cmd = CMD_SET_IP_MODE + bytes([1 if cfg.use_dhcp else 0])
        raw = _query_module(self._ser, cmd, timeout=0.2)
        _check_ack(raw)
        if cfg.use_dhcp:
            return
        cmd = CMD_SET_IP_ADDRESSES
        cmd += pack_ipv4(cfg.ip_addr)
        cmd += pack_ipv4(cfg.subnet)
        cmd += pack_ipv4(cfg.gateway)
        cmd += pack_ipv4(cfg.dns)
        raw = _query_module(self._ser, cmd, timeout=0.2)
        _check_ack(raw)

    def zero_all_sensors(self):
        self._require_connected()
        raw = _query_module(self._ser, CMD_ZERO_SENSORS, timeout=0.2)
        _check_ack(raw)

    def reboot(self):
        self._require_connected()
        raw = _query_module(self._ser, CMD_REBOOT, timeout=0.2)
        _check_ack(raw)
