import time
import threading
from queue import Queue
from enum import IntEnum
from delcom.interface import Interface, enumerate_modules


class State(IntEnum):
    DISCOVER = 0
    CONNECT = 1
    READ_VALUES = 2


class MsgCode(IntEnum):
    # persistent status
    INITIAL = 0x000
    DISCOVERING = 0x001
    MODULE_NOT_FOUND = 0x002
    CONNECT_FAILURE = 0x003
    QUERY_FAILURE = 0x004
    CONNECTED = 0x010

    # transitory messages
    TRANSITORY = 0x100
    CONNECTING = 0x101
    EXITING = 0x102
    MODULE_STATUS = 0x104
    SENSOR_STATUS = 0x105
    SENSOR_VALUES = 0x106


class Msg:
    def __init__(self, code: MsgCode, /, text: str = None, data=None):
        self.code = code
        self.text = text
        self.data = data


class PollingEngine:
    def __init__(self):
        self._mod = Interface()
        self._reset()

    def start(self, msg_queue: Queue, /, dev: str = None, usb_serial_num: str = None, interval: float = 0.2, format_str: bool = False, read_volts: bool = False):
        self._queue = msg_queue
        self._dev = dev
        self._usb_serial = usb_serial_num
        self._run = True
        self._state = State.DISCOVER
        self._interval = interval
        self._format_str = format_str
        self._read_volts = read_volts
        self._status = Msg(MsgCode.INITIAL, 'initial')
        self._thread = threading.Thread(target=poll_task, args=(self,))
        self._thread.start()

    def stop(self):
        if not self._thread:
            return
        self._run = False
        self._thread.join()
        self._reset()

    def module(self):
        """
        To be used as context manager
        """
        return self._mod

    def state(self):
        return self._state

    def _reset(self):
        self._queue = None
        self._dev = None
        self._usb_serial_num = None
        self._thread = None
        self._run = False
        self._state = State.DISCOVER
        self._status = None

    def _send_msg(self, code: MsgCode, /, text: str = None, data=None):
        msg = Msg(code, text, data)
        if code < 0x100:
            if code == self._status.code:
                return
            self._status = msg
        self._queue.put(msg)


def find_device(dev: str, usb_serial_num):
    mods = enumerate_modules()
    if len(mods) == 0:
        return None

    if dev == 'auto':
        dev = None

    if not dev and not usb_serial_num:
        return mods[0].device

    for mod in mods:
        if dev and dev == mod.device:
            return mod.device
        if usb_serial_num and usb_serial_num == mod.usb_serial_num:
            return mod.device
    return None


def poll_task(eng: PollingEngine):
    delay_end = None
    error_cnt = 0
    value_poll_time = None
    status_poll_time = None
    dev = None
    while eng._run:
        if eng._queue.qsize() > 10:
            # main thread might have crashed
            # if main thread is still alive, it can act on the EXITING code
            # call stop(), and then restart with start()
            break
        if delay_end:
            if time.time() < delay_end:
                time.sleep(0.1)
                continue
            delay_end = None
        if eng._state == State.DISCOVER:
            eng._send_msg(MsgCode.DISCOVERING, text='discovering modules')
            dev = find_device(eng._dev, eng._usb_serial_num)
            if not dev:
                eng._send_msg(MsgCode.MODULE_NOT_FOUND, text='interface module not found')
                delay_end = time.time() + 2.0
                continue
            eng._state = State.CONNECT
            error_cnt = 0
        elif eng._state == State.CONNECT:
            eng._send_msg(MsgCode.CONNECTING, text='connecting to module')
            with eng._mod as mod:
                try:
                    mod.connect(dev)
                except Exception as e:
                    eng._send_msg(MsgCode.CONNECT_FAILURE, text='unable to connect', data=str(e))
                    error_cnt += 1
                    if error_cnt > 3:
                        eng._state = State.DISCOVER
                    delay_end = time.time() + 2.0
                    continue
            status_poll_time = time.time()
            value_poll_time = time.time()
            eng._send_msg(MsgCode.CONNECTED, text='connected', data=dev)
            eng._state = State.READ_VALUES
            error_cnt = 0
        elif eng._state == State.READ_VALUES:
            now = time.time()
            remaining = value_poll_time - now
            if remaining > 0:
                if remaining > 0.1:
                    time.sleep(0.1)
                else:
                    time.sleep(remaining)
                continue
            with eng._mod as mod:
                try:
                    if eng._read_volts:
                        values = mod.read_sensor_voltages(eng._format_str)
                    else:
                        values = mod.read_sensors(eng._format_str)
                except Exception as e:
                    error_cnt += 1
                    if error_cnt > 3:
                        eng._send_msg(MsgCode.QUERY_FAILURE, text='unable to read values', data=str(e))
                        mod.disconnect()
                        eng._state = State.DISCOVER
                        delay_end = time.time() + 2.0
                    continue
            error_cnt = 0
            eng._send_msg(MsgCode.SENSOR_VALUES, data=values)
            value_poll_time += eng._interval

            if now < status_poll_time:
                continue
            with eng._mod as mod:
                try:
                    module_status = mod.read_status()
                    statuses = mod.read_sensor_status()
                except Exception as e:
                    error_cnt += 1
                    if error_cnt > 3:
                        eng._send_msg(MsgCode.QUERY_FAILURE, text='unable to read status', data=str(e))
                        mod.disconnect()
                        eng._state = State.DISCOVER
                        delay_end = time.time() + 2.0
                    continue
            error_cnt = 0
            eng._send_msg(MsgCode.MODULE_STATUS, data=module_status)
            eng._send_msg(MsgCode.SENSOR_STATUS, data=statuses)
            status_poll_time += 8.0
    eng._send_msg(MsgCode.EXITING, text='exiting')
    eng._mod.disconnect()
