from enum import IntEnum
from typing import Tuple


class Units(IntEnum):
    OHMS_PER_SQ = 0
    MHOS_PER_SQ = 1
    MICRONS = 2
    OHMS_CM = 3
    U_OHMS_CM = 4
    VOLTS = 5


UNITS_STRINGS = {
    0: 'ohms/sq',
    1: 'mhos/sq',
    2: 'microns',
    3: 'ohms-cm',
    4: 'micro-ohms-cm',
    5: 'volts'
}

# the ind_lo and ind_lo are indexes which select the multiplier
SCALE_MULTIPLIERS = {
    0: 0.01,
    1: 0.1,
    2: 1,
    3: 10,
    4: 100,
    5: 1000,
}


def calc_mhos(value: float, units: Units, thickness_um: float = None, resistivity_ohm_um: float = None) -> float:
    if units == Units.OHMS_PER_SQ:
        mhos = 1 / value
    elif units == Units.MHOS_PER_SQ:
        mhos = value
    elif units == Units.MICRONS:
        # resistivity_ohm_um = resistivity_ohm_cm * 10000
        if resistivity_ohm_um is None:
            raise ValueError('resistivity must be set for MICRONS')
        mhos = value / resistivity_ohm_um
    elif units == Units.OHMS_CM:
        if thickness_um is None:
            raise ValueError('thickness must be set for OHMS_CM')
        mhos = thickness_um / (value * 10000)
    elif units == Units.U_OHMS_CM:
        if thickness_um is None:
            raise ValueError('thickness must be set for U_OHMS_CM')
        mhos = thickness_um / (value / 100)     # value / 1000000 * 10000
    else:
        raise ValueError('unknown units value %s' % str(units))
    return mhos


def determine_range(scale_idx: int, units: Units, thickness_um: float = None, resistivity_ohm_um: float = None, slope_cal: float = 1.0) -> Tuple[float, float]:
    try:
        mult = SCALE_MULTIPLIERS[scale_idx]
    except KeyError:
        raise ValueError(f'scale_idx must be between 0 and 5, not {scale_idx}')

    vl = 0.0001 * mult * slope_cal
    vh = 2 * mult * slope_cal

    if units == Units.OHMS_PER_SQ:
        vl, vh = 1.0 / vh, 1.0 / vl
    elif units == Units.MHOS_PER_SQ:
        pass
    elif units == Units.MICRONS:
        # resistivity_ohm_um = resistivity_ohm_cm * 10000
        if resistivity_ohm_um is None:
            raise ValueError('resistivity must be set for MICRONS')
        vl, vh = resistivity_ohm_um * vl, resistivity_ohm_um * vh
    elif units == Units.OHMS_CM:
        if thickness_um is None:
            raise ValueError('thickness must be set for OHMS_CM')
        vl, vh = thickness_um / vh / 10000, thickness_um / vl / 10000
    elif units == Units.U_OHMS_CM:
        if thickness_um is None:
            raise ValueError('thickness must be set for OHMS_CM')
        vl, vh = thickness_um / vh * 100, thickness_um / vl * 100
    elif units == Units.VOLTS:
        vl, vh = (0.0001, 2.0)
    vl = round(vl, 6)
    vh = round(vh, 6)
    return vl, vh
